package com.oar.app;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
@Configuration
public class AppRoot {
/*
 @Configuration annotation in spring

@Configuration annotation in spring is use to eliminate the Spring Bean Configuration file means without Spring Bean 
configuration file we can get the dependency in spring framework.

@Configuration annotation in spring was introduced in Spring 3.0 and It provides an alternative to XML-based configuration.

@Configuration annotation indicates that a class declares one or more @Bean methods and may be 
processed by the Spring container to generate bean definitions and service requests for those beans at run time.
 */
	
	
	
	@Bean
	public HelloWorld getHelloWorld()
	{
		
		return new HelloWorld();
	}
	
	/*
	@Bean annotation in spring

@Bean annotation in spring is used to declare a single bean , the @Bean annotation returns an
 object that spring should register as bean in application context.

@Bean annotation in spring is alternate of <bean id=�beanid� class=�class_name�> 
tag of spring Bean Configuration file.

@Bean annotation in spring will be used along with @Configuration annotation 
	 * */
}
