package com.oar.app;

import org.springframework.beans.factory.annotation.Value;

public class HelloWorld {
	
	HelloWorld() {
System.out.println("-------HelloWorld--------------");

	
	}
	@Value("Hi welcome Jspider ")
	/*@Value annotation in spring is use to pass 
	 * default value  for the Pojo class property 
	 * and @Value annotation in spring is an alternate 
	 * of <propety> tag of Spring Bean Configuration file. */
	private String msg;
	

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}
	

}
